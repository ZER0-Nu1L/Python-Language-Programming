'''

A module that can be imported

-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in section 1.4.2 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''

ATP = -30.5
