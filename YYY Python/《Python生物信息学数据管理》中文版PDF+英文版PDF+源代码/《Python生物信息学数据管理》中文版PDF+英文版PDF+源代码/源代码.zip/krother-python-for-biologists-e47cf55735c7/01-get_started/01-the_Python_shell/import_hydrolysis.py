'''
Import a module from the same folder

-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in section 1.4.2 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''

from hydrolysis import ATP

print ATP
