'''
-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in section 2.3.5 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''
# running a for loop over a list of numbers
for i in [1, 2, 3, 4, 5]:
    print i

# range(10) creates a list of numbers from 0 to 9.
for number in range(10):
    print number,

