'''

Example for loop over a string.

-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in section 2.3.5 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''
for character in 'hemoglobin':
    print character,
