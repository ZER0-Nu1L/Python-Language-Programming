
seq = "IVGGYTCGANTVPYQVSLNSGYHFCGGSLINSQWVVSAAHCYKSGIQVRLGEDNINVVEGNEQF"

i = 0
while i < len(seq):
    print seq[i:i + 12]
    i = i + 12
