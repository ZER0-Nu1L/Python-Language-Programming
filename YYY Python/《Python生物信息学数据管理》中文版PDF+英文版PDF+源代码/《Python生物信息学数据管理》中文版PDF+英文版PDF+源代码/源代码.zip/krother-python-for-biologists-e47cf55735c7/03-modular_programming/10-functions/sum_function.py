'''

Define and call a function

-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in section 10.3.1 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''

def calc_sum(num1, num2):
    '''here you are defining the calc_sum function'''
    result = num1 + num2
    return result

# here you are calling calc_sum
print calc_sum(12, 8)		  
