'''

Set variables used by other modules.

-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in chapter 14 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''

input_seq = 'uniprot_seq/'
blast_out = 'blast_out/'
