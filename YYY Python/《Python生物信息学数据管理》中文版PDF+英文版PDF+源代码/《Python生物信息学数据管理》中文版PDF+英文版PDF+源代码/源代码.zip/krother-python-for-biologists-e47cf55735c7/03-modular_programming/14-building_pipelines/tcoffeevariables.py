'''
-----------------------------------------------------------
(c) 2013 Allegra Via and Kristian Rother
    Licensed under the conditions of the Python License

    This code appears in chapter 14 of the book
    "Managing Biological Data with Python".
-----------------------------------------------------------
'''

tcoffeeout = '/Users/allegra/Dropbox/Python_Book/NewChapters/Chapter14-BuildingPipelines/files&scripts/tcoffee/'
